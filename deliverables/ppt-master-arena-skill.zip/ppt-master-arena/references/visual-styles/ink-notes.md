# Visual style: ink-notes

Whiteboard-ink minimalism — a pale field, confident black hand-ink line work, sparse semantic color. Considered and manifesto-clear, the professional end of hand-drawn. For methodology, before/after essays, mindset-shift narratives, technical manifestos.

---

## 1. Shape & decoration

- Shape language: hand-drawn line work with slight, intentional wobble — boxes, arrows, dividers and brackets sketched as if on a thoughtful whiteboard. When a mark must read as hand-inked, realize it as `<path>` / `<polyline>` with off-grid points rather than a pristine primitive. Functional native contours remain eligible; line defines structure, while repeated filled-card grids are not the default grammar.
- Composition geometry: a circled central concept with branch arrows carrying the page; a hand-drawn Venn or overlap sketch as the argument; strike-through-and-replace geometry for before/after; one oversized bracket grouping the evidence under the claim.
- Decoration: minimal — a few doodle marks (stars, dashes, dots, underlines) for emphasis. Restraint is the look; clutter breaks the "considered" feel.
- Whitespace: generous and empty; the pale field carries most of the canvas, elements float with room around them.

## 2. Typography character

- Hand-lettered / humanist character for titles — bold, slightly oversized, confident. Plain legible sans for body.
- Reads as written-by-hand-but-deliberate, not corporate-precise.

> Families are chosen at confirmation `g`; this style asks for a humanist / hand-lettered title *character*. This governs editable native text; decorative-lettering eligibility remains a separate carrier decision.

## 3. Using the deck's colors

- Near-monochrome: ink-dark line work on a pale field carries the composition; the deck's accent remains a sparse semantic mark for risk, positive state, or emphasis.
- Color carries meaning, not decoration; use only the accents that signify something on the current page.

> HEX values come from confirmation `e`; this style only governs the monochrome-with-semantic-accent discipline — it names no colors.

## 4. Texture / elevation

- Strictly flat — no shadows, no paper grain (the field stays clean). Depth reads from line weight and spacing alone.

## 5. Paired image-rendering

`ink-notes` — black-ink visual-note imagery on a clean field, matching the considered hand-drawn aesthetic.

## 6. Illustration propensity

**supportive** — when illustration is selected, hand-ink elements can anchor, annotate, or connect a composition while the style's considered restraint remains intact. Role, scale, reuse, and placement stay Strategist judgment; an explicit user request wins either way, and `image_usage: none` writes no illustration rows.
