# ppt-master-arena（反重力 Antigravity 版）

AI 驱动的可编辑 PPT/PPTX 生成技能。输入一个主题，产出 **可编辑** 的 PowerPoint
（原生图表、表格、形状、流程、图标），支持 AI 插画、演讲者备注、动画与旁白视频。
本版本由 Arena Agent Mode 基于上游 [hugohe3/ppt-master](https://github.com/hugohe3/ppt-master)
打包，保留完整工作流与 tabler-outline 图标库，精简了本包用不到的音频与 AI 插图对比素材。

## 安装到反重力（Antigravity）

1. 解压 `ppt-master-arena.zip`，得到 `ppt-master-arena/` 文件夹。
2. 把该文件夹整体放入 Agent 的 skills 目录（例如 `~/.antigravity/skills/` 或
   工作区 `./skills/`），使路径形如 `skills/ppt-master-arena/SKILL.md`。
3. 安装 Python 依赖：

   ```bash
   pip install -r skills/ppt-master-arena/requirements.txt
   # 最小可用子集（中文 PPT 必需）：
   pip install Pillow python-pptx lxml
   ```

4. 重启/刷新 Agent，当你说「做一份 PPT / 生成可编辑幻灯片 / 做课程汇报」时，
   Agent 会自动加载本技能。

## 一次典型流程（中文 16:9 学术汇报）

```bash
SKILL=skills/ppt-master-arena
# 1. 初始化项目
python3 $SKILL/scripts/project_manager.py init my_topic
# 2.（可选）AI 插画：在 design_spec.md / spec_lock.md 中规划 images，
#    生成图片放到 <project>/images/
# 3. 按 spec 逐页写 SVG 到 <project>/svg_output/
# 4. 同步图标（tabler-outline 已内置在 templates/icons/）
python3 $SKILL/scripts/icon_sync.py <project> tabler-outline/xxx ...
python3 $SKILL/scripts/analyze_images.py <project>/images
# 5. 质量门（必须 0 error）
python3 $SKILL/scripts/svg_quality_checker.py <project> --stage final --json
# 6. 演讲者备注：写 notes/total.md，按页拆分
python3 $SKILL/scripts/total_md_split.py <project>
# 7. 内嵌图标/图片 -> 导出可编辑 PPTX（含备注）
python3 $SKILL/scripts/finalize_svg.py <project>
python3 $SKILL/scripts/svg_to_pptx.py <project>
# 产物在 <project>/exports/*.pptx
```

## 示例作品

包内 `examples/` 附一份完整成品示例：《机器学习筛选鲜味肽》15 页中文学术汇报
（2 张 AI 插画 + 4 个原生图表 + 3 个原生表格 + 15 页演讲者备注），可直接打开参考。

## 关键约束（踩坑速查）

- 画布 16:9 为 `viewBox="0 0 1280 720"`；字体栈用
  `"Microsoft YaHei","PingFang SC","Noto Sans CJK SC",Arial,sans-serif`。
- 顶层 `<g>` 必须带 `id` + `data-pptx-bounds`；图标用 `<use data-icon="...">`（禁 stroke）。
- 禁 `mask/<style>/class/animate/foreignObject/<br/>`；颜色用 6 位大写 HEX。
- native chart/table 的 `<metadata>` 里不要写 `axes`/`title` 键；表格 columns/rows
  文本必须与回退文本逐字一致；图表标题/轴文字必须在回退 SVG 中可见。
- 质量门 0 个 blocking error 才能导出。

## 许可

MIT，见 [LICENSE](LICENSE)；图标库第三方归属见
`templates/icons/THIRD_PARTY_NOTICES.md`。
