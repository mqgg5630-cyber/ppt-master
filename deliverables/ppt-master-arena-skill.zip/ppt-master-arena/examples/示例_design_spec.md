<!-- ppt-master-schema: design-spec/v1 -->
# 机器学习筛选鲜味肽 - Design Spec

## I. Project Information

| Item | Value |
| --- | --- |
| Project Name | umami_peptide_ml |
| Canvas Format | PPT 16:9 (ppt169), 1280×720 |
| Page Count | 15 |
| Primary Language | zh-CN |
| Target Audience | 食品科学、生物信息学方向研究生与科研人员（学术组会/研讨会场景） |
| Communication Intent | 教学型系统讲解：让受众完整理解鲜味肽为何值得筛、传统方法为何慢、机器学习如何实现高通量虚拟筛选、模型性能演进、应用与挑战；以证据链建立专业可信度 |
| Desired Audience Outcome | 受众能复述 ML 筛选鲜味肽完整技术路线（数据→特征→模型→评价→对接→验证），说出至少 3 个代表模型及准确率水平，并能判断应用点 |
| Core Message / Ask / Action | 机器学习把鲜味肽发现从大海捞针式湿实验转变为数据驱动的高通量虚拟筛选：预测准确率已达 90% 以上，配合分子对接与感官验证形成「预测—验证」双轨，正成为食品风味研发新范式 |
| Delivery Context | 线下/线上学术汇报，投影放映为主，兼顾会后阅读 |
| Artifact Afterlife | 会后作为课题背景资料分发归档；页面需可编辑，便于替换为自己的课题数据 |
| Reading Mode | balanced |
| Content Strategy | 以 topic-research 事实对为唯一外部事实来源；模型性能、数据集规模、案例数字均标注来源，不虚构数据 |
| Design Style | 浅色学术科技风：论文式留白、青绿科技 accent、鲜味橙点睛；圆角卡片 + 细线分割 |
| AI Image Acquisition Path | host-native |
| Generation Mode | continuous |
| Spec Refinement | disabled |
| Speaker Notes | enabled — 用户在 Stage-2 明确选择启用 |
| Custom Animations | disabled — 默认（页面淡入过渡、无对象动画） |
| Narration Audio | disabled |
| Created Date | 2026-08-28 |

## II. Canvas Specification

| Property | Value |
| --- | --- |
| Format | ppt169 (PPT 16:9) |
| Dimensions | 1280 × 720 |
| viewBox | `0 0 1280 720` |
| Margins | 左右 64px，上下 48px 安全边距 |
| Content Area | x: 64–1216，y: 48–672；标题带 y≈56–120，内容区 y≈140–640，页脚 y≈676 |

## III. Visual Theme

### Theme Style

- **Mode**: custom
- **Mode References**: instructional, pyramid
- **Mode Behavior**: 教学骨架五幕：背景价值（P01–P03）建立问题张力，方法分解（P04–P09）按数据→酶解→特征→算法→评价流水线逐页递进并以箭头相连，证据收束（P10–P13）用时间线、对比图、工具表让受众得出「越来越准」结论，案例落地（P14）走通完整研究，展望收束（P15）；页标题用断言句，方法页保留编号步骤。
- **Visual style**: custom
- **Visual Style References**: soft-rounded, swiss-minimal
- **Visual Style Behavior**: 近白冷灰纸面大留白，1px 细分割线建立论文式网格；内容用 8–12px 圆角浅色卡片配极轻投影，实心色块只用于步骤节点、关键数字与强调标签；形状语言为圆点节点+圆角矩形+细线箭头，呼应肽链分子节点；无渐变堆砌、无重装饰；内容页共享页眉细线、左上章节标签与右下页码。
- **Theme**: 学术科研 + 生物信息 + 食品风味交叉学科气质
- **Tone**: 专业、清晰、克制、可信，带少量鲜味暖橙的味觉联想温度

### Color Scheme

| Role | HEX | Purpose |
| --- | --- | --- |
| Background | #F7FAFA | 页面近白底（冷调纸白） |
| Secondary background | #FFFFFF | 卡片/内容容器纯白 |
| Primary | #123A5D | 深海军蓝：标题、主结构、深色块 |
| Accent | #0E8F86 | 青绿：科技主 accent、步骤节点、流程主线、图表主色 |
| Secondary accent | #E8743B | 鲜味橙：关键数字、重点高亮、味觉元素 |
| Body text | #2B3A46 | 正文深灰蓝 |
| Muted text | #6B7C8A | 注释、来源、次级说明 |
| Tint primary | #E6EFF6 | 浅蓝底卡片 |
| Tint accent | #E2F2F0 | 浅青绿底 |
| Tint orange | #FCEBDF | 浅橙底 |
| Chart blue | #5B8DB8 | 图表辅助蓝 |
| Chart gray | #B9C6CF | 图表灰/基线 |

### AI Image Strategy

- **Image Rendering**: custom
- **Image Rendering References**: vector-illustration, flat
- **Image Rendering Behavior**: 干净扁平矢量科研插画，2–3px 等粗描边与几何平涂色块、无渐变无照片质感；母题为肽链圆球节点、Y 形 T1R1/T1R3 受体轮廓、试管培养皿、芯片网络节点；配色严格继承 deck 色板；留白充足、横向构图、文字区安静；情绪精密理性带清新食欲。
- **Visual**: 扁平几何 + 科学示意图语汇
- **Mood**: 理性精密 × 清新食欲，类比高水平综述期刊配图

## IV. Typography System

### Font Plan

| Role | Character (Reference) | Primary | English if non-English | Fallback tail |
| --- | --- | --- | --- | --- |
| Title | 现代无衬线、粗体 | Microsoft YaHei | Arial | sans-serif |
| Body | 无衬线常规 | Microsoft YaHei | Arial | sans-serif |
| Data | 等宽数字/英文术语 | Consolas | Consolas | monospace |

- **Title stack**: "Microsoft YaHei", "PingFang SC", "Noto Sans CJK SC", Arial, sans-serif
- **Body stack**: "Microsoft YaHei", "PingFang SC", "Noto Sans CJK SC", Arial, sans-serif
- **Data stack**: Consolas, "Courier New", monospace

### Font Size Hierarchy

| Purpose | Anchor Size (px) |
| --- | ---: |
| Hero（封面大标题） | 46 |
| Page Title | 30 |
| Subtitle / 卡片标题 | 22 |
| Body | 20 |
| Annotation（注释/来源/标签） | 15 |
| Data Big（大数字 KPI） | 44 |

## V. Layout Principles

### Deck-wide Direction

- **Hierarchy direction**: 顶部页眉（章节标记）→ 断言式页标题 → 内容区（左主右辅 / 流程从左到右 / 卡片网格）→ 底部来源注脚
- **Composition tendency**: 方法页以横向流程/编号步骤为主干；证据页以图表/表格为视觉中心；卡片对齐隐形网格；关键数字用大字号 KPI
- **Cross-page continuity**: 所有内容页共享页眉章节标签、右下页码；青绿步骤节点与橙色高亮语义跨页一致
- **Spacing posture**: anchor 页大留白；dense 页卡片紧凑但保留分组间距

## VI. Icon Usage Specification

- **Primary bundled library**: tabler-outline
- **Brand-logo library**: 无品牌 logo 需求
- **Stroke Width**: 2

| Icon Path | Suitable Scenarios |
| --- | --- |
| tabler-outline/flask | 鲜味肽/湿实验/感官验证 |
| tabler-outline/database | 数据集/数据库 |
| tabler-outline/binary-tree | 特征编码/序列表征 |
| tabler-outline/brain | 机器学习/深度学习模型 |
| tabler-outline/chart-bar | 评价指标/性能对比 |
| tabler-outline/atom-2 | 分子对接/受体 |
| tabler-outline/search | 虚拟筛选/高通量 |
| tabler-outline/bulb | 挑战与展望/关键发现 |
| tabler-outline/clock | 耗时瓶颈 |
| tabler-outline/coin | 成本瓶颈 |
| tabler-outline/arrow-right | 流程箭头 |
| tabler-outline/refresh | 迭代/训练 |
| tabler-outline/world | 在线 web 服务器 |
| tabler-outline/file-text | 序列数据/FASTA |
| tabler-outline/test-pipe | 酶解/虚拟水解 |
| tabler-outline/check | 验证通过/优势 |
| tabler-outline/alert-triangle | 挑战/局限 |
| tabler-outline/network | 神经网络/BERT |
| tabler-outline/filter | 筛选漏斗 |
| tabler-outline/cpu | 计算/高通量 |
| tabler-outline/soup | 食品/发酵食品 |
| tabler-outline/link | 相互作用/氢键对接 |

## VII. Visualization Reference List

| Page | Family | Template | Usage |
| --- | --- | --- | --- |
| P03 | chart | chart/grouped_bar_chart | 传统湿实验 vs 计算虚拟筛选在时间、成本、通量三维度的定性对比条 |
| P08 | chart | chart/horizontal_bar_chart | ML 算法三代演进谱系（代际分组横向条） |
| P09 | chart | chart/donut_chart | 评价指标概念环（ACC/MCC/Sn/BACC/auROC 五指标） |
| P12 | chart | chart/column_chart | 代表模型准确率柱状图：0.824→0.888→0.91→0.905→0.932→0.94，含 0.90 参考线与断裂轴 |
| P06 | table | table/record_table | 三大基准数据集对照：UMP442 / UMP499 / UMP789 |
| P11 | table | table/record_table | 在线预测工具表 |
| P14 | table | table/record_table | 腐乳案例 5 条验证肽紧凑表 |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Layout pattern | Crop Policy | Acquire Via | Status | Reference | text_policy | page_role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| hero_peptide_receptor.png | 1376×768 | 16:9 | 封面主视觉：肽链与鲜味受体科技插画 | hero illustration | 全幅封面底图，主体（肽链→Y形受体）集中在画面右侧 55%，左侧留安静冷白区域承载大标题；左下放置小试管/分子点缀 | no-crop | ai | Generated | 扁平矢量科研插画：圆球节点短肽链（含橙色 D/E 残基）结合到 Y 形 T1R1/T1R3 受体二聚体轮廓；海军蓝线条、青绿主体、鲜味橙高光、近白底；无文字 | none | hero_page |
| outlook_future.png | 1376×768 | 16:9 | 结尾展望页配图：AI 驱动肽设计未来图景 | section illustration | 右侧约 45% 插画块（圆角卡片内或出血），左侧放展望要点；画面中央为 AI 芯片/神经网络与肽链螺旋交织，周围环绕受体、食品（汤）与试管图标 | no-crop | ai | Generated | 扁平矢量未来感插画：中心神经网络/芯片与螺旋肽链交织，向外连接受体、发酵食品碗与试管图标，形成「数据→设计→食品」闭环；海军蓝结构线、青绿主视觉、橙色亮点、近白底；无文字 | none | local |

## IX. Content Outline

### Part 1: 背景与问题

#### Slide 01 - 封面
- **Audience move**: 从「什么主题」→ 被强论断吸引，期待了解 ML 如何改变鲜味肽研发
- **Layout**: 全幅 AI 插画为底（右侧主体），左侧冷白安静区竖排标签、大标题、副标题、KPI；底部细线
- **Title**: 机器学习筛选鲜味肽
- **Core message**: 数据驱动虚拟筛选把鲜味肽发现从大海捞针变成按图索骥
- **Content**: 主标题「机器学习筛选鲜味肽」；副标题「从序列到呈味：AI 驱动的鲜味肽高通量虚拟筛选」；标签「食品风味化学 × 生物信息学 × 机器学习」；KPI 标签（预测准确率 >90% · 毫秒级打分 · 万级候选一次筛完）；汇报人/单位/日期占位
- **Images**: hero_peptide_receptor.png 全幅
- **Cover impact**: Hook = 「>90% 准确率 + 毫秒级预测」对比湿实验数月周期；AI hero 图右重左轻
- **Fact IDs**: F006, F007

#### Slide 02 - 什么是鲜味肽
- **Audience move**: 从「知道鲜味好吃」→ 理解鲜味肽是有结构规律的短肽、知道受体机制
- **Layout**: 左侧定义+三特征卡，右侧受体示意图（原生 SVG 绘制 T1R1/T1R3 Y 形二聚体 + 肽链结合）
- **Title**: 鲜味肽：第五种味觉背后的小分子
- **Core message**: 鲜味肽是能结合 T1R1/T1R3 受体呈鲜的短肽，序列富含酸性氨基酸
- **Content**: ①鲜味受体主要为 T1R1/T1R3 异源二聚体（C 类 GPCR），谷氨酸与 IMP/GMP 协同增鲜；②鲜味肽多为 2–8 肽，分子量 <3000 Da；③序列富含 D、E，A/S/G 协同，2025 DL 识别 D/E/Q/K/R 关键残基；④来源：肉、海鲜、菌菇、大豆发酵食品
- **Fact IDs**: F001, F002, F004, F006

#### Slide 03 - 为什么需要新的筛选范式
- **Audience move**: 认同传统发现路径慢且贵，高通量方法是刚需
- **Layout**: 上方湿实验路径流程条，下方三痛点卡，右侧定性对比条图，底部过渡结论带
- **Title**: 传统筛选：在肽的海洋里「大海捞针」
- **Core message**: 分离纯化—质谱—感官评价路径耗时耗力，无法应对海量候选肽
- **Content**: 传统路径五步（蛋白水解→分离纯化→LC-MS/MS→人工合成→感官评价）；三痛点：耗时、昂贵、低通量；定性对比图（通量/成本/耗时三维度）；过渡句「机器学习让先算后验成为可能」
- **Visualization**: pain-compare=yes（chart/grouped_bar_chart 定性对比条）
- **Fact IDs**: F007, F008

### Part 2: 机器学习筛选技术路线

#### Slide 04 - 总体技术路线
- **Audience move**: 获得完整路线图，后续每页是其中环节放大
- **Layout**: 横向六步流程图（编号节点+卡片+箭头），上方干/湿实验泳道标签，下方数据飞轮回注箭头，底部结论带
- **Title**: 完整流水线：「预测—验证」双轨
- **Core message**: ML 预测从万级候选富集，对接与感官实验确证，结果回流
- **Content**: 六步：①数据收集 ②虚拟酶解 ③特征编码 ④模型预测（核心，深色卡）⑤分子对接 ⑥实验验证；①–⑤干实验，⑥湿实验；验证结果回流训练集
- **Fact IDs**: F008, F009, F010

#### Slide 05 - 数据基础
- **Audience move**: 理解候选库构建与正负样本来源
- **Layout**: 左侧三来源卡（数据库/文献/虚拟酶解），右侧候选库构建纵向流程
- **Title**: 数据层：候选肽从哪里来
- **Core message**: 正样本来自实验验证肽与 BIOPEP-UWM，负样本多为苦味肽；虚拟酶解批量造库
- **Content**: BIOPEP-UWM 数据库；文献验证肽；虚拟酶解（蛋白序列→2–8 肽库）；PeptideRanker 概率 >0.5 初筛 + 毒性/致敏/吸收/半衰期逐级过滤
- **Fact IDs**: F009, F010

#### Slide 06 - 基准数据集演进（表）
- **Audience move**: 看到训练数据规模增长支撑模型进步
- **Layout**: 上部三数据集对照表格，下部两张说明卡（数据扩充/SMOTE 不平衡处理）
- **Title**: 基准数据集：从 UMP442 到 UMP789
- **Core message**: 数据规模与质量持续扩充是模型性能提升的燃料
- **Content**: 表：UMP442（140/302，iUmami-SCM、UMPred-FRL）、UMP499（212/287，Umami-MRNN）、UMP789（Umami-BERT）；SMOTE 过采样平衡类别
- **Visualization**: dataset-table=yes（table/record_table）
- **Fact IDs**: F010, F011, F012, F015, F007

#### Slide 07 - 特征编码
- **Audience move**: 理解序列表征是 ML 关键，手工特征与深度表征两条路线
- **Layout**: 顶部「序列→向量」转换示意，下方手工特征（浅卡）vs 深度表征（深蓝卡）对照
- **Title**: 特征工程：从氨基酸序列到数值向量
- **Core message**: 手工特征可解释但有噪声冗余；预训练语言模型自动提特征成主流
- **Content**: 手工特征 AAC（20 维）/DPC（400 维）/CTD/PAAC/APAAC/Mordred 描述符；深度表征 BERT 蛋白预训练模型两阶段训练、注意力可解释；手工特征依赖专家经验是早期误差来源
- **Fact IDs**: F010, F013, F007

#### Slide 08 - 模型算法谱系
- **Audience move**: 纵览模型谱系与代际演进
- **Layout**: 三代演进横向条带（传统 ML→深度学习→预训练大模型），底部 UMPred-FRL 集成示例带
- **Title**: 算法演进：从 SVM 到 BERT
- **Core message**: 模型从手工特征+经典 ML 走向端到端序列表征学习
- **Content**: ①传统 ML：SVM/RF/ET/KNN/LR/PLS/GBDT；②深度学习：MLP/CNN/RNN-LSTM（Umami-MRNN）；③预训练：BERT/Transformer 两阶段+对比学习（iUP-BERT、Umami-BERT、2025 模型）；UMPred-FRL = 6 算法×7 编码集成，ACC 0.888
- **Visualization**: algo-genealogy=yes（chart/horizontal_bar_chart 代际分组）
- **Fact IDs**: F010, F015, F012, F006

#### Slide 09 - 模型评价与验证
- **Audience move**: 掌握如何判断模型好坏
- **Layout**: 左侧五指标甜甜圈概念图，右侧五指标卡，底部深蓝验证协议流程
- **Title**: 怎么判断模型「准不准」
- **Core message**: 交叉验证+独立测试+多指标，MCC 对不平衡数据更可靠；最终仍需湿实验确证
- **Content**: 指标 ACC/MCC（−1~1，不平衡稳健）/Sn（灵敏度）/BACC/auROC；10 折交叉验证→独立测试集→湿实验确证；SMOTE 处理不平衡；指标高≠感官呈鲜
- **Visualization**: metric-donut=yes（chart/donut_chart 概念环）
- **Fact IDs**: F010, F007

### Part 3: 模型进展、工具与应用

#### Slide 10 - 模型演进时间线
- **Audience move**: 看到 2020–2025 真实研究脉络
- **Layout**: 横向时间线 6 节点（2020→2025），每节点年份+方法标签+卡片，底部结论带
- **Title**: 五年模型演进：准确率节节攀升
- **Core message**: 从评分卡到 BERT 到对比学习，方法与数据双轮驱动
- **Content**: 2020 iUmami-SCM（评分卡，0.824）→2021 UMPred-FRL（集成，0.888）→2022 iUP-BERT（BERT+SVM）/VirtuousUmami（通用味觉）→2023 Umami-MRNN（0.905）/Umami-BERT（93.2%，可解释）→2024 VmmScore（预测+受体匹配）→2025 对比学习（0.94，模块替换设计）
- **Fact IDs**: F011, F010, F007, F013, F015, F012, F017, F006

#### Slide 11 - 在线工具与资源
- **Audience move**: 知道可立刻上手的工具
- **Layout**: 左侧工具表格（6 工具），右侧深蓝「快速上手」三步卡
- **Title**: 开箱即用：在线预测服务器
- **Core message**: 主流模型都有免费 web 服务器，输入序列即可高通量打分
- **Content**: 表：iUmami-SCM/UMPred-FRL/iUP-BERT/Umami-BERT/VirtuousUmami（SMILES/FASTA/InChI、开源）/VmmScore；配套 BIOPEP-UWM、PeptideRanker；快速上手三步
- **Visualization**: tools-table=yes（table/record_table）
- **Fact IDs**: F010, F007, F012, F013, F017, F009

#### Slide 12 - 性能对比
- **Audience move**: 被性能数据说服：模型已足够准
- **Layout**: 中央大柱状图（6 模型 ACC，0.90 参考虚线、断裂轴标记），右侧两 KPI 卡+一结论卡
- **Title**: 准确率：从 82% 到 94%
- **Core message**: 五年准确率提升约 12 个百分点，深度学习稳定站上 90%
- **Content**: 柱状图：iUmami-SCM 0.824、UMPred-FRL 0.888、iUP-BERT ≈0.91、Umami-MRNN 0.905、Umami-BERT 0.932（平衡集）、2025 DL 0.94；KPI：最高 94%、+12pp、MCC 最高 0.85；纵轴 0.80–1.00 截断并标注断裂轴；数据集不同看趋势
- **Visualization**: acc-compare=yes（chart/column_chart）
- **Fact IDs**: F011, F010, F015, F007, F012, F006

#### Slide 13 - 分子对接
- **Audience move**: 理解计算如何提供机制证据
- **Layout**: 左侧对接结合模式示意（肽段嵌入口袋、氢键虚线、Arg277 标注），右侧三要点卡
- **Title**: 分子对接：从「猜得准」到「说得清」
- **Core message**: 对接模拟揭示肽与 T1R1/T1R3 结合模式，提供机制层证据
- **Content**: ①对接原理（结构互补+能量匹配）；②关键作用：氢键/疏水/盐桥，DFEGDV 的 D 与 Arg277 关键盐桥，结合 Venus flytrap 域；③工具 AutoDock、VmmScore ML 打分；局限：力场耗时，ML 打分函数加速
- **Fact IDs**: F005, F008, F017

#### Slide 14 - 应用案例：腐乳鲜味肽虚拟筛选
- **Audience move**: 看到完整研究如何跑通全流程
- **Layout**: 上部四步流程条，中部三 KPI 卡，下部 5 条验证肽表，表外意义注脚
- **Title**: 案例：从腐乳发酵中「算」出 5 条新鲜味肽
- **Core message**: 肽组学+随机森林+分子对接+感官的双轨在真实食品体系跑通
- **Content**: ①肽组学追踪 0–90 天，前 60 天关键窗口；②随机森林等 ML 筛 637 种潜在鲜味肽（准确率约 89%），30%+ 源自 11 种大豆蛋白特定位点；③对接锁定 5 肽（DFEGDV、GRGPTVTDP、NDDRDSYNL、RVPAGTTY、SDNFEY）；④感官阈值 0.22–0.38 mmol/L，鲜味强度比 MSG 高 3–5 倍
- **Visualization**: case-peptides=yes（table/record_table 五肽表）
- **Fact IDs**: F005

### Part 4: 挑战与展望

#### Slide 15 - 挑战、展望与收束
- **Audience move**: 理性认识局限、看到未来方向，带走核心结论
- **Layout**: 左侧三挑战卡，右侧 AI 插画，右下展望方向卡，底部青绿结论带
- **Title**: 未来：从「预测鲜味」到「设计鲜味」
- **Core message**: 数据规模、可解释性、定量泛化仍是挑战；AI+对接+实验闭环走向肽的从头设计
- **Content**: 挑战：①数据规模小/不平衡 ②可解释性浅 ③跨集泛化与阈值/强度定量回归；展望：多任务多味觉学习、AI 从头设计（模块替换已验证）、预测—对接—验证闭环自动化、低钠调味品与副产物高值化；结论带：筛选从月到秒 · 准确率 >90% · 双轨范式已成
- **Images**: outlook_future.png 右侧
- **Closing impact**: 收束于「从预测鲜味到设计鲜味」+ 结论带
- **Fact IDs**: F006, F007, F008, F016

## X. Speaker Notes Requirements

- **Generation**: enabled
- **Filename**: notes/total.md 由 total_md_split.py 按页拆分到 notes/，与 svg_output 一一对应（p01…p15）
- **Content**: 每页讲稿以该页最终 SVG 信息为依据，中文学术报告口吻；含核心论点、关键数字与来源、过渡句；自然语言带出来源，不罗列 URL
- **Total duration**: 约 20–25 分钟（15 页）
- **Notes style**: formal（学术汇报）
- **Presentation purpose**: instruct + report
